<?php
//Database connection
$con = mysql_connect('localhost','root','');
$select_db = mysql_select_db('test',$con) or die(mysql_error());

//Store transaction information from PayPal
$item_name = $_REQUEST['item_name'];
$item_number = $_REQUEST['item_number']; 
$txn_id = $_REQUEST['txn_id'];
$payer_email = $_REQUEST['payer_email'];
$payment_gross = $_REQUEST['payment_gross'];
$payment_status = $_REQUEST['payment_status'];

//Inser tansaction data at the database
$insert = mysql_query("INSERT INTO payments(item_name,item_number,txn_id,payer_email,payment_gross,payment_status) VALUES('".$item_name."','".$item_number."','".$txn_id."','".$payer_email."','".$payment_gross."','".$payment_status."')") or die(mysql_error());
$last_insert_id = mysql_insert_id();

if($last_insert_id){
?>
	<h1>Your payment has been successful.</h1>
    <h1>Your Payment ID - <?php echo $last_insert_id; ?>.</h1>
<?php
}else{
?>
	<h1>Your payment has failed.</h1>
<?php
}
?>