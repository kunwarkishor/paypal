<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PayPal Transaction Cancel - CodexWorld</title>
</head>
<body>
	<h1>Your PayPal transaction has been canceled.</h1>
</body>
</html>