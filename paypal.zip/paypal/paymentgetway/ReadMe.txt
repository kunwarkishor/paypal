Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: info@codexworld.com

============ Instruction ============

Create a database named "test" => import products.sql and payments.sql file into the test database

Or follow the below instruction for manually table creation. 

Open the "products.php" file => change database host, username and password => change databse name => change PayPal business email.

Open the "products.php" file => change database host, username and password => change databse name.


============ May I Help You ===========
If you have any query about this script, please feel free to contact us at contact@codexworld.com. We will reply as soon as possible.